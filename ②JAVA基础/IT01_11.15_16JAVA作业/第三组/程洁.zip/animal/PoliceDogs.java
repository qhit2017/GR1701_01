package animal;

public class PoliceDogs extends Dogs{
	
	float maxspeed;
	
	void maxspeed(){
		System.out.println("\n����ٶ�:\t\t"+maxspeed+"m/s");
	}
	void working(String working){
		System.out.println(working);
	}
}