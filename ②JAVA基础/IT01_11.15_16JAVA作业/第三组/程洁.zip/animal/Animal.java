package animal;

public class Animal {
	int legs;
	String eyescolor;
}