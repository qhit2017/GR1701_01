package animal;

public class Test {
	public static void main(String[] args) {
		
	
	Cat cat=new Cat("��������",75.2,3);
    cat.type ="��������";
    System.out.println(cat.type);
	cat.eat("food");
    cat.climbtree();
    cat.sleep();
    cat.setColor("è");
    System.out.println(cat.getColor());
    
    cat.color();
    	
    
    
}
}