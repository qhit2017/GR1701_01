package dog;

public class Zoology {
	int number;
	String color;

	void number() {
		System.out.println(6);
	}

	void color() {
		System.out.println("��ɫ");
	}
}
