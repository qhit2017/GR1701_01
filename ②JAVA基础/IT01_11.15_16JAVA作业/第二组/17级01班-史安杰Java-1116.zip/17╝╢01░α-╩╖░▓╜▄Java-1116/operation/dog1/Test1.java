
public class Test1 {
	public static void main(String[] args) {
		Dog1 dog = new Dog1();
		dog.setBreed("��Ȯ");
		dog.setColor("��ɫ");
		dog.setAge(3);
	    dog.setWeight(70);
	    System.out.println();
	    dog.message();
	    System.out.println("�ڽ�");
	    dog.bark();
	    System.out.println("��");
	    dog.eat();
	    System.out.println("˯");
	    dog.sleep();
	}

}
