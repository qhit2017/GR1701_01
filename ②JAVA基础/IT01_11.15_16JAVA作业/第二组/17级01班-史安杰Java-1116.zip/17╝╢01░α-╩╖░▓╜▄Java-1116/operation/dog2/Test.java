package dog;

public class Test {
	public static void main(String[] args) {
		Jichengdog speedperhour = new Jichengdog();

		speedperhour.work();
		speedperhour.color();
		speedperhour.number();
	}

}
