package dog;

public class Jichengdog extends Dog {
	double speedperhour;

	void work() {
		System.out.println("���ʱ��");
	}

}
