package shianjie;

import java.util.Scanner;

public class Shianjie_1106 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("С��ʲ�ļ���");
	int egg=sc.nextInt();
	if (egg<5)
	System.out.println("�ͳԵ�");
	else
	System.out.println("���˵�");
	
			
	
	
	
	
	
}
}
