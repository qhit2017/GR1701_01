package shianjie;

public class Mysecondjob {
	
public static void main(String[] args) {
	int bo=324;
	System.out.println(bo%10);
	System.out.println(bo/10%10);
	System.out.println(bo/100);
}
}