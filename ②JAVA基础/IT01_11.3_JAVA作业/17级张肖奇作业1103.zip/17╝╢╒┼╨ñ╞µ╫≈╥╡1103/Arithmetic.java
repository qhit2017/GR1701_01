package shianjie;

public class Arithmetic {
	
public static void main(String[] args) {
	int io=0;
	int io1=15;
	int io2=4;
	//���������
	System.out.println(io);
	System.out.println(io1+io2);
	System.out.println(io1-io2);
	System.out.println(io1*io2);
	System.out.println(io1/io2);
	System.out.println(io1%io2);
	
	
}
}
