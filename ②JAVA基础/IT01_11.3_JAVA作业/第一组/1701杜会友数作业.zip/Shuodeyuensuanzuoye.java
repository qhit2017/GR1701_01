package jsuanchenxu;

import java.util.MissingFormatArgumentException;

/** 
 * @author  ���� E-mail:2291425946.com
 * @date    ����ʱ�䣺2017��11��3�� ����5:28:30 
 * @version 1.8 
 * @parameter  
 * @since  
 * @return  
 * @function
 */
public class Shuodeyuensuanzuoye {
	public static void main(String[] args) {
		
		int a=2346;
		int b=3;
		double c=1.25;
		int d;
		d=a/1000;
		System.out.println("���ļӼ��˳�");
		System.out.println(a+b+c);
		System.out.println(a-b-c);
		System.out.println(a*b);
		System.out.println(a/c);
		System.out.println(a%b);
		System.out.println("��ҵ���ְ�ʮ����λ");
		System.out.println(d);
		System.out.println(a/100%10);
		System.out.println(a/10%10);
		System.out.println(a%10);
		
	}

}
