public class O1119 {
	public static void main(String[] args) {
		
		for (int i = 1; i <= 5; i++) {
			for (int a = 1; a <= 5; a++) {

				System.out.println(i + "��" + a);

			}
		}
	}

}
