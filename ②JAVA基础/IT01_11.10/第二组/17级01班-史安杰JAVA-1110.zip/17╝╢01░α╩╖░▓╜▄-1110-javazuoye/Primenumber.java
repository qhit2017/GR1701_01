package primenumber;

public class Primenumber {
	public static void main(String[] args) {
		boolean z;
		int w = 0;
		for (int a = 2; a <= 1000; a++) {
			z = true;
			for (int s = 2; s < a; s++) {
				if (a % s == 0) {
					z = false;
					break;

				}
			}
			if (z) {
				System.out.print(a + "\t");

				w++;
				if (w%8==0){
					System.out.println();

				}
			}
		}
	}

}
