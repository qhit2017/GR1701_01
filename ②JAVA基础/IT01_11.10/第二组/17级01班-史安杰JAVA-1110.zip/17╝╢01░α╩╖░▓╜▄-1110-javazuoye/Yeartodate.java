package yeartodate;

import java.util.Scanner;

public class Yeartodate {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("������һ�����");
		int year=sc.nextInt();
		System.out.println("������һ���·�");
		int month=sc.nextInt();
		System.out.println("������һ�����");
		int day=sc.nextInt();
		
		int days=0;
		switch(month){
		case 12:
			days+=30;
		case 11:
			days+=31;
		case 10:
			days+=30;
		case 9:
			days+=31;
		case 8:
			days+=31;
		case 7:
			days+=31;
		case 6:
			days+=30;
		case 5:
			days+=31;
		case 4:
			days+=30;
		case 3:
			if((year%4==0&&year%100==0)||(year%400==0)){
				days+=29;
			}	else{
				days+=28;
			}
			
			
		case 2:
			days+=31;
		case 1:
			days+=day;
			
			
			
			
			
		}System.out.println("�Ǹ���ĵ�"+days+"��");
		
		
	}

}
