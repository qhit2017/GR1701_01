package tobuychicken;

public class Tobuychicken {
	public static void main(String[] args) {
		for(int gj=0;gj<=20;gj++){
		for(int mj=0;mj<=33;mj++){
		for(int xj=0;xj<=300;xj++){
		if((gj+mj+xj==100)&&(gj*5+mj*3+xj/3==100)&&(xj%3==0)){
			System.out.println("����"+gj+"ĸ��"+mj+"С��"+xj);
		}
		}
		}
		}
	}
}
