package com;



public class PrimeNumber1 {
	public static void main(String[] args) {
		boolean isprime;
		for (int a = 2; a <= 1000; a++) {
			isprime = true;
			for (int b = 2; b < a; b++) {
				if (a % b == 0)
					isprime = false;
				break;
			}

			if (isprime) {
				System.out.println(a);
			}

		}

	}

}
