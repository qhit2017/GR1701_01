package com;

public class Chick1 {
	public static void main(String[] args) {
		for(int a=0;a<=20;a++){
			for(int b=0;b<=33;b++){
				for(int c=0;c<=100;c++){
					if(c%3==0&&a+b+c==100){
						if(5*a+3*b+c/3==100){
							System.out.println("�������"+a);
							System.out.println("ĸ��"+b);
							System.out.println("С��"+c);
					}
				}
				
		}
		
			}
		}		
}
}	
