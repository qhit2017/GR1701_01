package jtc;

import java.util.Scanner;

public class Zuoye3 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=1;
	int sum=0;
	while(a<=5){
		System.out.println("�������"+a+"��ѧ���ɼ�");
	sum=sum+ sc.nextInt();
	
	a++;
	}
	System.out.println("sum�ǣ�"+sum);
	System.out.println("average�ǣ�"+sum/5);
	sc.close();
}
	
	
	
	
	
	
	
	
}

