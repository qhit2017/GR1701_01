package jtc;

public class Zuoye {
public static void main(String[] args) {
	int a = 1;
	while (a<100){
		if((a%3==0)||(a%4==0)){
		System.out.println(a);
		}a++;
	}
	
			
			
			
			
			
}
}
