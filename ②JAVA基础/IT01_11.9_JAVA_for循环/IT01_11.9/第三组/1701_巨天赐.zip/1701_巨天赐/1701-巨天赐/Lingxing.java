/**
 * 
 */
package rhombus;

import java.util.Scanner;

/**
 * @author ���� E-mail:1123996281@qq.com
 * @date ����ʱ�䣺9 Nov 2017 8:19:34 Ntambama
 * @version 1.0
 * @parameter
 * @since
 * @return
 * @function
 */
/**
 * @author Administrator
 *
 */
public class Rhombus {
	public static void main(String[] args) {

		for (int m = 1; m <= 10; m++) {
			for (int n = 9; n >= m; n--) {
				System.out.print(" ");
			}
			for (int n = 1; n <= m; n++) {
				System.out.print("*");
			}
			for (int n = 1; n < m; n++) {
				System.out.print("*");
			}
			System.out.println();
		}

		for (int m = 1; m < 10; m++) {
			for (int n = 1; n <= m; n++) {
				System.out.print(" ");
			}
			for (int n = 9; n >= m; n--) {
				System.out.print("*");
			}
			for (int n = 9; n > m; n--) {
				System.out.print("*");
			}
			System.out.println();

		}

	}

}
