package jtc;

public class Zuoye8 {
public static void main(String[] args) {
	int hundred = 0;
	int tens = 0;
	int units = 0;

	for (int k = 1; k < 1000; k++) {

		hundred = k / 100;
		tens = k / 10 % 10;
		units = k % 10;

		if (k == (hundred * hundred * hundred + tens * tens * tens + units
				* units * units)) {
			System.out.println("����ˮ�ɻ������ǣ�" + k);
		}
}
}
}