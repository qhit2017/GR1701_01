
public class Zuoye2 {
public static void main(String[] args) {
	int i =1;
	int product =1;
	while (i<=10){
		product= product*i;
		i++;
	}
	System.out.println("��˵Ľ����"+i);
	
	
	
}
}
