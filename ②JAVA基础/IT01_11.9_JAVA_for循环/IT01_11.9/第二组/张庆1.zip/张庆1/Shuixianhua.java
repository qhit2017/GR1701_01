package zhangqing;

public class Daffodil {
	public static void main(String[] args) {
		    int a =0;
			int b=0;
			int c=0;
			for(int d=100; d<=1000;d++){
				a =d/100;
				b=d/10%10;
				c=d%10;
			if((d==a*a*a+b*b*b+c*c*c)){
				System.out.println("ˮ�ɻ����ǣ�"+d);
			}
			}
	}
}
