/** 
 * @author  ���� E-mail:743371327@qq.com
 * @date    ����ʱ�䣺2017��11��2�� ����7:10:49 
 * @version 1.0 
 * @parameter  
 * @since  
 * @return  
 * @function
 * @
*/
package changwang;

public class Juxing {
	public static void main(String[] args) {
		System.out.print("*************");
		System.out.print("*           *");
		System.out.print("*           *");
		System.out.print("*           *");
		System.out.print("*           *");
		System.out.print("*************");
	}

}
