package Reclangle.java;
/**
 *���ߣ�����
 *����ʱ�䣺2017
 */
public class Reclange {
public static void main(String[] args) {
	/**
	System.out.println("****************");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("*              *");
	System.out.println("****************");
	System.out.println("��\t��");
	*/

}}
